<?php include 'db_connect.php' ?>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    color: #ffffff96;
}
.imgs{
		margin: .5em;
		max-width: calc(100%);
		max-height: calc(100%);
	}
	.imgs img{
		max-width: calc(100%);
		max-height: calc(100%);
		cursor: pointer;
	}
	#imagesCarousel,#imagesCarousel .carousel-inner,#imagesCarousel .carousel-item{
		height: 60vh !important;background: black;
	}
	#imagesCarousel .carousel-item.active{
		display: flex !important;
	}
	#imagesCarousel .carousel-item-next{
		display: flex !important;
	}
	#imagesCarousel .carousel-item img{
		margin: auto;
	}
	#imagesCarousel img{
		width: auto!important;
		height: auto!important;
		max-height: calc(100%)!important;
		max-width: calc(100%)!important;
	}
</style>

<div class="containe-fluid">
	<div class="row mt-3 ml-3 mr-3">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <?php echo "Welcome back ". $_SESSION['login_name']."!"  ?>
                    <hr>	            
                </div>
            </div>      			
        </div>
    </div>
</div>



<script>
	$('#manage-records').submit(function(e){
        e.preventDefault()
        start_load()
        $.ajax({
            url:'ajax.php?action=save_track',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success:function(resp){
                resp=JSON.parse(resp)
                if(resp.status==1){
                    alert_toast("Data successfully saved",'success')
                    setTimeout(function(){
                        location.reload()
                    },800)

                }
                
            }
        })
    })
    $('#tracking_id').on('keypress',function(e){
        if(e.which == 13){
            get_person()
        }
    })
    $('#check').on('click',function(e){
            get_person()
    })
    function get_person(){
            start_load()
        $.ajax({
                url:'ajax.php?action=get_pdetails',
                method:"POST",
                data:{tracking_id : $('#tracking_id').val()},
                success:function(resp){
                    if(resp){
                        resp = JSON.parse(resp)
                        if(resp.status == 1){
                            $('#name').html(resp.name)
                            $('#address').html(resp.address)
                            $('[name="person_id"]').val(resp.id)
                            $('#details').show()
                            end_load()

                        }else if(resp.status == 2){
                            alert_toast("Unknow tracking id.",'danger');
                            end_load();
                        }
                    }
                }
            })
    }
</script>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css"/>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&display=swap" rel="stylesheet">
  </head>
  <body>
      <main class="main-container">
        <div class="main-cards">
          <div class="card">
            <div class="card-inner">
              <p>CLIENTS</p>
              <div class="icon icon-shape background-blue text-primary">
                <i class="fa-solid fa-users" style="color : #ffffffff "></i>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-inner">
              <p>VENUES</p>
              <div class="icon icon-shape background-green text-primary">
                <i class="fa-solid fa-location-dot" style="color : #ffffffff "></i>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-inner">
              <p>EVENTS</p>
              <div class="icon icon-shape background-orange text-primary">
                <i class="fa-regular fa-calendar-days" style="color : #ffffffff "></i>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-inner">
              <p>EARN</p>
              <div class="icon icon-shape background-red text-primary">
                <i class="fa-solid fa-dollar-sign" style="color : #ffffffff "></i>
              </div>
            </div>
          </div>

        </div>

        <div class="charts">
          <div class="charts-card">
            <p class="chart-title">CLIENTS</p>
            <canvas id="bargraph"></canvas>
          </div>

          <div class="charts-card">
            <p class="chart-title">VENUES</p>
            <div id="map"></div>
          </div>

          <div class="charts-card">
            <p class="chart-title">EVENTS</p>
            <canvas id="piegraph" style="height: 200; width: 200;"></canvas>
          </div>

          <div class="charts-card">
            <p class="chart-title">EARN</p>
            <canvas id="linegraph" style="height:350px"></canvas>
          </div>
        </div>
      </main>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/chart.min.js"></script>
    <script src="js/clientbar.js"></script>
    <script src="js/venuemap.js"></script>
    <script src="js/eventpie.js"></script>
    <script src="js/earnline.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/aa5f332820.js" crossorigin="anonymous"></script>
  </body>
</html>