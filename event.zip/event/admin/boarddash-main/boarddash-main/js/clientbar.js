$(document).ready(function(){
    $.ajax({
      url: "http://localhost/boarddash/client.php",
      method: "GET",
      success: function(data) {
        console.log(data);
        var months = [];
        var clients = [];
  
        for(var i in data) {
          months.push(data[i].months);
          clients.push(data[i].clients);
        }
  
        var chartdata = {
          labels: months,
          datasets : [
            {
              label: 'Clients in Every Month',
              backgroundColor: 'rgba(255, 0, 132, 1)',
              hoverBackgroundColor: 'rgba(178, 0, 92, 1)',
              data: clients
            }
          ]
        };
  
        var ctx = $("#bargraph");
  
        var barGraph = new Chart(ctx, {
          type: 'bar',
          data: chartdata
        });
      },
      error: function(data) {
        console.log(data);
      }
    });
  });