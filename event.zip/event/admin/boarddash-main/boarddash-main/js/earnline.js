$(document).ready(function(){
  $.ajax({
    url: "http://localhost/boarddash/earn.php",
    method: "GET",
    success: function(data) {
      console.log(data);
      var months = [];
      var earn = [];

      for(var i in data) {
        months.push(data[i].months);
        earn.push(data[i].earn);
      }

      var chartdata = {
        labels: months,
        datasets : [
          {
            label: 'Monthly Income',
            backgroundColor: 'rgba(57, 255, 253, 0.8)',
            hoverBackgroundColor: 'rgba(178, 0, 92, 1)',
            data: earn
          }
        ]
      };

      var ctx = $("#linegraph");

      var lineGraph = new Chart(ctx, {
        type: 'line',
        data: chartdata
      });
    },
    error: function(data) {
      console.log(data);
    }
  });
});