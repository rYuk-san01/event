<!DOCTYPE html>
<html>
    <head>
        <title>Event Management System</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
        body{
            background-image: url("13.jpg");
            /*background-color: #9D00ff;*/
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
            .container{
                align-items:center;
                height: 40rem;
                width: 25rem;
                backdrop-filter: blur(1 px);
                overflow: hidden;
                padding:25px;
                margin: 0 auto;
                border: DOUBLE white 10px;
                position: relative;
                border-radius: 0.8rem;
            }
            .form-label {
                color: white;
                font-weight: bold;
                font-size: 30px;
                margin: 10px;

            }
            .form-control{
                height: 50px;
            }
            .btn{
                background-color: white;
            }
            .btn:hover{
                background-color: red;
                color: white;
            }
            </style>
        </head>
    <?php
    require 'connection.php';
    ?>
    <div class="container">
        <form action="index.php" method="post">
            
            <div class="mb-3 mt-3">
                <label for="username" class="form-label des">Username:</label>
                <input type="text" class="form-control" id="username" placeholder="Enter Username" name="Username">
            </div>
            <div class="mb-3">
                <label for="pwd" class="form-label">Password:</label>
                <input type="password" class="form-control" id="pwd" placeholder="Enter Password" name="Password">
            </div>
            <div class="form-check mb-3">
                <label class="form-check-label">
                <input class="form-check-input" type="checkbox" name="remember"> Remember me</label>
            </div>
            <button type="submit" class="btn" name="submit">Log in</button><br><br><p>Don't have an account yet?</p>
        </form>
        <form action="registerko.php" method="post">
            <button type="submt" class="btn" name="submt">Register</button>
        </form>
<br>
<br>
        <form action="admin/login.php" method="post">
         <!-- <center><button type="submt" class="btn" name="submt">Admin</button></center>-->
        </form>
    </div>
    </body>
</html>